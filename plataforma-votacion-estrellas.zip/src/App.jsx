import React, { useState, useEffect } from "react";

const cantantes = [
  {
    id: 1,
    nombre: "Cantante 1",
    foto: "https://via.placeholder.com/150",
    audio: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"
  },
  {
    id: 2,
    nombre: "Cantante 2",
    foto: "https://via.placeholder.com/150",
    audio: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3"
  },
  {
    id: 3,
    nombre: "Cantante 3",
    foto: "https://via.placeholder.com/150",
    audio: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3"
  },
  {
    id: 4,
    nombre: "Cantante 4",
    foto: "https://via.placeholder.com/150",
    audio: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3"
  }
];

const App = () => {
  const [votos, setVotos] = useState({});
  const [bloqueado, setBloqueado] = useState(false);
  const [enviado, setEnviado] = useState(false);

  useEffect(() => {
    const bloqueo = localStorage.getItem("votacionFinalizada");
    if (bloqueo === "true") {
      setBloqueado(true);
    }
  }, []);

  const votar = (id, valor) => {
    if (bloqueado || enviado) return;
    setVotos({ ...votos, [id]: valor });
  };

  const enviarVotacion = () => {
    if (Object.keys(votos).length < 3) {
      alert("Debes votar por al menos 3 cantantes.");
      return;
    }
    setBloqueado(true);
    setEnviado(true);
    localStorage.setItem("votacionFinalizada", "true");
    alert("¡Gracias por tu votación!");
  };

  const promedio = (valor) => {
    const estrellas = Array(5).fill("☆");
    for (let i = 0; i < valor; i++) estrellas[i] = "★";
    return estrellas.join(" ");
  };

  return (
    <div className="p-4 max-w-5xl mx-auto">
      <h1 className="text-3xl font-bold text-center mb-6">Votación de Cantantes</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {cantantes.map((c) => (
          <div key={c.id} className="border rounded-xl p-4 shadow text-center">
            <img src={c.foto} alt={c.nombre} className="w-32 h-32 object-cover rounded-full mx-auto" />
            <h2 className="text-xl font-semibold mt-2">{c.nombre}</h2>
            <audio controls src={c.audio} className="w-full my-2" />
            <div className="flex justify-center gap-1 my-2">
              {[1, 2, 3, 4, 5].map((num) => (
                <button
                  key={num}
                  className={`text-2xl ${votos[c.id] >= num ? "text-yellow-500" : "text-gray-400"}`}
                  onClick={() => votar(c.id, num)}
                  disabled={bloqueado}
                >
                  ★
                </button>
              ))}
            </div>
            {votos[c.id] && (
              <p className="text-sm">Tu voto: {promedio(votos[c.id])}</p>
            )}
          </div>
        ))}
      </div>
      <div className="text-center mt-6">
        {!bloqueado && (
          <button
            onClick={enviarVotacion}
            className="bg-blue-600 text-white px-6 py-2 rounded text-lg hover:bg-blue-700 disabled:bg-gray-400"
          >
            Enviar votación
          </button>
        )}
        {bloqueado && <p className="mt-4 text-green-600 font-bold">Ya has votado. ¡Gracias!</p>}
      </div>
    </div>
  );
};

export default App;